# Static validation report — 2026-10-05

## Scope and result

**All 26 checks passed:** 14 application/helper unittest checks plus 12 complete-checkout
composition/integrity checks, using Python standard library and bash only. The repository
checks live in `tests/integration_checks.py` (run from repository root). Release maintenance
must rerun both suites. ZIP/WAR CRC and per-file SHA256 are verified by the supplied packaging helpers.
No baseline file is assumed unchanged merely because it existed in an earlier package:
`tests/baseline-manifest.json` in the full checkout classifies every baseline file precisely.

## Checks performed

- Python syntax and every shell script with `bash -n`; embedded cloud-init/traffic shell blocks
  are checked separately. No installer, apt, systemd or guest command is executed.
- XML Servlet 4.0 routes/display name, javax compatibility, JSP lexical delimiter/source
  contracts, SQL-independent health, 503 DB failure behavior, prepared SQL inputs, output
  escaping, root UI/data endpoints and source-to-WAR identity. Not a Java/JSP compiler check.
- Fictional private JNDI XML/password round trips including quotes, dollars, angle brackets,
  token-like text and newlines; root-only unattended JSON seed input without a prompt;
  unsafe seed ownership/mode refusal. Real credentials are never used in tests or packaged.
- Bounded Tomcat connector/JVM/JDBC pool, non-root service, both Tomcat directory trees and
  sudo ls/netstat discovery-check intent, while protecting the JNDI descriptor at 0640.
- Idempotent bounded hosts edits, fictional captured-file restoration, mocked systemctl state
  restoration and explicit existing-lab-only rollback guard. No live rollback was tested.
- Fictional JDBC class-header fixture structural checks and runtime ZIP per-file provenance.
  The fixture is deleted, never supplied as a prerequisite. Driver signatures/availability
  were not validated; target HTTPS retrieval or the reviewed-checksum local route is required.
- Mocked HTTP-only generator reads/posts through Nginx, no Python SQL client/password,
  traffic disable preserving application prerequisites and safe Windows password encoding.
- Static deploy → helper/runtime embedding → cloud-init composition with tricky fictional
  passwords; one-pass escaping; required WAR/runtime assets; SQL preparation before final
  data/proxy readiness; unchanged schema/seed statement; no fresh Node execution.
- PowerShell BOM/ASCII, lexical here-string endings and selected helper definition-before-call
  checks. **No actual PowerShell AST parser ran locally.** Deployment performs a real combined
  source parser check on its Windows target client; run `scripts/check-lab-scripts.ps1` there
  with Windows PowerShell 5.1 before release.
- Full-checkout diff manifest, untouched baseline bytes, local documentation links and removal
  of personal/session/workspace pointers. Module 4 and unrelated host/appliance behavior stay
  unchanged. The obsolete dated parser report is intentionally not delivered.

## Required target execution (not performed here)

No Java, javac, Maven or PowerShell runtime was available and no packages were installed.
No Azure/Hyper-V deployment, SSH, live SQL/JDBC, Tomcat startup/JSP compilation, socket
ownership, appliance discovery/assessment or migration was exercised. Structural/lexical
success does not prove those outcomes. Filesystem permission tests verify requested intent;
actual Ubuntu ownership/modes and discovery identity access must be checked on target.

For initial builds, validate early SQL-independent 3000 liveness, delayed SQL recovery,
final health/info/ready/orders/page/proxy checks, one explicit insert/read-back, non-root Java
socket ownership, discovery credential directory read/execute and sudo tools, reboot,
optional traffic on/off, and migration alias repointing. Record actual installed package,
Java and driver versions/SHA256. Test both default driver retrieval and any required local
prerequisite route. Appliance SSH/credential mapping is a separate check.

Existing-lab fallback only: stage on 3001, validate data/write, explicitly switch to 3000,
verify proxy and captured-state rollback. Initial deployments need no staging/cutover and
have no previous Node service to restore. No essential initial integration is deferred.

## Reproduce

From the application directory:

```bash
python3 build.py war
python3 build.py runtime
python3 tests/static_checks.py
```

From the complete repository root:

```bash
python3 tests/integration_checks.py
python3 build.py zip --output ../azure-migrate-workshop-tomcat.zip
```
