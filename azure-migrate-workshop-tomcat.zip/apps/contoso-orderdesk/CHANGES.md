# Contoso Order Desk changes

## Integrated initial deployment

- Tomcat 9/OpenJDK 17 on port 3000 is the default Linux-App runtime, with the included original
  WAR and complete JSP source. No fresh Node installation or manual cutover is required.
- Initial SQL setup creates the shared restricted labapp login using the protected deployment
  password. Cloud-init waits for liveness only; final host validation requires SQL/data/proxy
  readiness before success. Nginx keeps its separate original port-80 site.
- Added deterministic minimal runtime ZIP, SHA256 guards, unattended root-only JSON seed input,
  bounded pinned JDBC retrieval and explicit locally checksum-verified prerequisite fallback.
- Optional HTTP-only traffic uses the real JVM JDBC pool for database work. Disable never
  removes the primary application's SQL login, proxy or hosts.
- Discovery validation checks both CATALINA_HOME/BASE directory read/execute and sudo ls/netstat.
  Personal account/session references and deferred-fresh-build instructions were removed.
- Existing-lab 3001 staging, explicit switch and captured-state rollback remain available as a
  fallback, not a step in a new deployment. No target runtime/discovery test is claimed here.
