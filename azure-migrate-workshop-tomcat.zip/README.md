# TD SYNNEX | Azure Migrate Hyper-V Workshop

**Cloud Enablement Services** · Partner hands-on training

Work through the guides linked below in order. Each module builds on the environment the previous one left behind.

Discover, assess, test and migrate four Hyper-V VMs to Azure, then validate and clean up the environment. All four workloads use the **Hyper-V host replication provider**. The discovery appliance performs assessment; the replication provider on the Hyper-V host moves VM data. SQL Server does not require a different replication architecture simply because it stores data. [Microsoft Hyper-V migration tutorial](https://learn.microsoft.com/azure/migrate/tutorial-migrate-hyper-v)

**Release status:** awaiting a full live Azure/Hyper-V run. Validate the scripts end to end in a training subscription before partner delivery, and record the revision you used.

## Current runtime and complete checkout

Initial deployment includes Tomcat 9/OpenJDK 17, the original named WAR, protected JNDI
credentials, SQL mixed mode/shared restricted login, lab aliases and Nginx desk/API proxy.
No manual app install, extra password prompt or traffic command is needed by students.
SQL-independent health precedes SQL setup; final success requires actual SQL readiness/data,
named UI and proxy readiness. Discovery credentials still need appliance-side validation.
The `AgentBased` wrapper/filter remains a Module 3 grouping/instructor agentless shortcut,
not proof of a Mobility Service migration path or a waiver of guest discovery permissions.

The checkout contains all app source, WAR/runtime binary assets and rebuild/tests under
[apps/contoso-orderdesk](apps/contoso-orderdesk/README.md). A new checkout has no workspace
or output-folder dependency. Read the pinned JDBC/local-checksum prerequisite options there.
Run `python3 tests/integration_checks.py` and app static checks, then the real Windows
PowerShell 5.1 `scripts/check-lab-scripts.ps1` before release. `python3 build.py zip --output
../azure-migrate-workshop-tomcat.zip` packages the complete checkout with per-file SHA256 guards. No Java/SQL/appliance test is
claimed by the static validation report. Existing-lab 3001 staging is a separate fallback,
not part of new deployment.

## Learning path

Provision the environment before the teaching session. Budget a full working day for initial delivery; actual deployment, discovery, replication and backup time depends on bandwidth, quota and regional capacity. Measure the duration yourself before advertising a timed agenda.

| Module | Exercise | Completion evidence |
|---|---|---|
| 0 | [Setup](docs/Module-0-Setup.md) | Four nested VMs healthy on fixed disks; `E:` appliance store present |
| 1 | [Discovery and assessment](docs/Module-1-Discovery.md) | Four workload names discovered and an Azure VM assessment; optionally a populated dependency map via the [lab traffic mesh](docs/Lab-Traffic.md) |
| 2 | [Agentless migration](docs/Module-2-Agentless-Migration.md) | OnPrem-Web and OnPrem-Linux-Web replicated and test-migrated with no agent installed |
| 3 | [Agent-based migration](docs/Module-3-Agent-Based-Migration.md) | OnPrem-SQL and OnPrem-Linux-App replicated continuously, then cut over with SQL data compared |
| 4 | [Azure Migrate vs. Site Recovery](docs/Module-4-ASR-Comparison.md) | Explain one-time migration versus ongoing disaster recovery |
| 5 | [Post-migration operations](docs/Module-5-Post-Migration.md) | Monitoring evidence, optional backup/restore, cost and security review |
| Finish | Cleanup | Test/replication artifacts and all workshop resources accounted for |

## Environment

```mermaid
flowchart LR
  subgraph Source["Source resource group · 10.0.0.0/16"]
    Host["HyperVHost · Windows Server 2022\nStandard_E8s_v7 · 8 vCPU / 64 GB\n512 GB OS disk: C: guests · E: appliance store\nStandard security"]
    subgraph Nested["intSwitch · NAT + DHCP reservations · 192.168.0.0/24"]
      IIS["OnPrem-Web · .10 · IIS"]
      SQL["OnPrem-SQL · .11 · SQL Express 2022"]
      Nginx["OnPrem-Linux-Web · .12 · Nginx"]
      App["OnPrem-Linux-App · .13 · Tomcat 9 / OpenJDK 17"]
      Appliance["MigrateAppl · .20\nImported in Module 1 from the appliance VHD\n8 vCPU / 16 GB"]
    end
    Project["Azure Migrate project"]
    Appliance -->|Discover and assess| Host
    Appliance -->|Metadata| Project
  end
  subgraph Destination["Target resource group"]
    Test["Isolated test VNet · 10.2.0.0/16\nOwn NAT gateway for egress"]
    Target["Target VNet · 10.1.0.0/16\nOwn NAT gateway for egress"]
  end
  Host -->|Host provider replication| Project
  Project --> Test
  Project --> Target
```

This is a **single nested Hyper-V host**, not a cluster or a production landing zone. Its internal NAT topology is a workshop adaptation. Microsoft documents an external switch for a production appliance deployment; validate the nested topology yourself and do not describe it as production support certification. [Appliance prerequisites](https://learn.microsoft.com/azure/migrate/deploy-appliance-script)

The IIS and Nginx port-80 sites remain static. **Contoso Order Desk** is now a real lightweight Java/JSP application on Linux-App: it reads/writes the unchanged `ContosoApp` Customers/Orders tables through a bounded JDBC pool. Nginx provides a separate desk/API proxy on 8080; optional generators are not needed for application setup.

## Start here

1. Read [Module 0](docs/Module-0-Setup.md), including subscription, quota, licensing, downloads and cost preparation.
2. Obtain the repository and record the exact commit shown below. For partner delivery, supply the release tag or commit you validated so every learner uses the same revision. Run these commands in a terminal, then continue from the repository directory:

   ```bash
   git clone --branch <reviewed-tomcat-branch> <workshop-repository-url>
   cd azure-migrate-workshop
   git rev-parse HEAD
   ```

3. In a PowerShell session with the current Az modules, choose your dedicated subscription and variables:

```powershell
Connect-AzAccount

# Masked at the prompt so they are not readable over a shared screen
$secureSubscriptionId = Read-Host 'Workshop subscription ID' -AsSecureString
$secureAdminCidr = Read-Host 'Your public IPv4 address' -AsSecureString
$password = Read-Host 'Lab-only administrator password' -AsSecureString

$sourceRg = 'rg-ces-source-01'
$location = 'eastus'

.\scripts\deploy-lab.ps1 -SubscriptionId $secureSubscriptionId `
    -ResourceGroupName $sourceRg -Location $location `
    -AdminUsername 'labadmin' -AdminPassword $password -AdminSourceCidr $secureAdminCidr
```

### Two ways to launch

`deploy-lab.ps1` runs the same way either from an open PowerShell window or from a right-click
**Run with PowerShell**. Every value it needs is a mandatory parameter, so PowerShell prompts
for anything not supplied, and the three sensitive ones are masked as you type.

On a right-click launch the window closes the instant the script ends, so the script holds it
open at the finish and after a failure, and writes a full error report next to itself
(`deploy-lab-error-<timestamp>.log`, with GUIDs redacted). Set `LAB_NO_PAUSE=1` to skip the
pause for an unattended run.

In an open window it also clears any leftover `Write-Host` / `Write-Warning` override left
behind by a `migrate-step` script run earlier in that session. Those scripts install console
overrides to mask subscription IDs, and a leftover one used to make `deploy-lab.ps1` fail on a
`Write-Host` line.

The `migrate-step` scripts are built for an open window. They work from a right-click too and
hold the window open the same way, but they are interactive throughout — they ask which
resource group, which project, which VM — so a console you can read and scroll back through is
the better fit.

Every `migrate-step` script then runs on its own, with no arguments:

```powershell
.\scripts\migrate-step1-setup-project.ps1
```

Each one loads the Az modules it needs, signs you in if the session is not signed in, offers a choice of subscription when none is current, and then lists the resource groups, projects and VMs it finds so you pick from what exists rather than typing names. Passing values on the command line still works and skips the matching question:

```powershell
.\scripts\migrate-step2-discover-assess.ps1 -SourceResourceGroup $sourceRg
```

The deployment scripts require **new, dedicated resource groups**. They intentionally refuse existing groups: replaying setup after cutover could restart the retired source VMs. They do not register the appliance or start replication. Complete Module 1 next.

## Which script completes which module step

The scripts and the modules are run separately. Each script also carries this in its own
`MODULE COVERAGE` block — `Get-Help .\scripts\<script>.ps1 -Full` shows it.

| Script | Completes |
|---|---|
| `deploy-lab.ps1` | Module 0 §4 in full; Module 1 §2 in full; Module 1 §3.3 download and extract only when opted in |
| `migrate-step1-setup-project.ps1` | **Optional.** Module 2 §4.1 (target landing zone), as an instructor shortcut — the student builds the same thing in the portal there. Module 1 §1 is **not** automated; it prints the portal steps |
| `migrate-step2-discover-assess.ps1` | Module 1 §3.2–3.5, §4 and §5. §3.1 (project key) stops for you |
| `migrate-step3-replicate.ps1` | Module 2 §5–§7, or Module 3 §8–§9, per `-Workload` |
| `migrate-step3a-agentless.ps1` | Module 2 §5–§9 in one run |
| `migrate-step3b-agent-based.ps1` | Module 3 §8–§11 end state — **not** §5–§7 (Mobility Service) |
| `migrate-step4-test-migrate.ps1` | Module 2 §8, or Module 3 §10, per `-Workload` |
| `migrate-step5-cutover.ps1` | Module 2 §9, or Module 3 §11, per `-Workload` |
| `migrate-step6-post-migration.ps1` | Module 5 §2–§5 |
| `enable-lab-traffic.ps1` | Module 0 §6; supplies what Module 1 §6 needs to show anything |
| `cleanup-lab.ps1` | Teardown. Leaves the Migrate project, key vault and recovery vault |
| `check-lab-scripts.ps1` | Nothing — maintenance tool |

Nothing automates Module 4: it is analysis, with no lab state to reach.

## Script responsibilities

| Script | Behavior |
|---|---|
| `deploy-lab.ps1` | Billable source host, nested guests on fixed disks, DHCP/NAT and samples; creates the `E:` appliance store partition; protected setup parameters; fails if readiness is not observed |
| `host/configure-host.ps1` | Runs inside the Windows host; creates the four workload VMs and stages the optional traffic generator |
| `migrate-step1-setup-project.ps1` | Billable target/test network preparation; portal project creation follows |
| `enable-lab-traffic.ps1` | Optional; staged on HyperVHost by deployment and run there with its generated settings file. Wires the four workloads into one order desk so dependency analysis has real traffic to observe; `-Disable` stops generators without removing the application prerequisites |
| `migrate-step2` – `migrate-step5` | Discovery/assessment, replication, test migration and cutover helpers for Modules 1–3. Steps 3–5 accept `-Workload All\|Agentless\|AgentBased` |
| `migrate-step3a-agentless.ps1` | Bridges the lab to the end state of **Module 2** (OnPrem-Web, OnPrem-Linux-Web) in one run |
| `migrate-step3b-agent-based.ps1` | Bridges the lab to the end state of **Module 3** (OnPrem-SQL, OnPrem-Linux-App). Reaches that state agentlessly — see CHANGES.md |
| `migrate-step6-post-migration.ps1` | Configures monitoring, backup, security rules and cost controls on migrated VMs; creates or changes Azure resources |
| `check-lab-scripts.ps1` | Parses every lab script without running any of them; reports file, line and column for anything that will not parse |
| `cleanup-lab.ps1` | Lists the resource group's contents, confirms, deletes the group, then reports what went and what must still be removed by hand. Refuses to start when a CanNotDelete lock is present |

## Costs and teardown

Estimate the host, OS disk, target/test VMs, replicated disks/storage, **two NAT gateways and their public IPs**, monitoring ingestion, optional Bastion and optional backup/DR. Use the [Azure pricing calculator](https://azure.microsoft.com/pricing/calculator/) for your region and agreement. There is no verified fixed daily price for this workshop. Deallocating VMs stops VM compute charges but does not remove billable disks, NAT gateways, IPs or retained backups.

```powershell
.\scripts\cleanup-lab.ps1 -ResourceGroupName $targetRg
.\scripts\cleanup-lab.ps1 -ResourceGroupName $sourceRg
```

The script takes one resource group per run and confirms before deleting. Review what it lists before confirming; `-Force` skips the prompt.

Deleting the two resource groups does not finish the teardown. A soft-deleted key vault keeps
its name reserved, a Recovery Services vault holding backup items refuses to be deleted, and the
appliance's Microsoft Entra app registration is not an Azure resource at all. `cleanup-lab.ps1`
prints all of them, with the commands to check, at the end of every run — including a cancelled
one. Clear them before you close out, or the next lab fails in ways that look unrelated.

> The `migrate-step` and `cleanup-lab` scripts take no subscription parameter. They act on whichever subscription is active in your session, so confirm it with `Get-AzContext` first.

## A note from the author

These notes record environment issues met while building and running this lab, and why parts of the scripts look the way they do. They are observations from one subscription and one region, not a compatibility matrix.

**The host size default changed from `Standard_E8s_v5` to `Standard_E8s_v7`.** The v5 size was not available to the subscription this lab was built in. Esv7 offers the same 8 vCPU / 64 GB shape and reports nested virtualization support, so it became the default. `deploy-lab.ps1` validates whatever size you pass against your own subscription's SKU metadata and quota, so a different family works if it meets the lab's floor.

**Esv7 is a Generation 2 only series, and its sizes require an OS image with NVMe support.** The workshop's Windows Server 2022 Gen2 host image satisfies both. If you change the host image, check those two properties first.

**Deployment pins the image catalog API version and forces Standard security on the temporary guest disk.** Both are deliberate. Letting the installed Az.Compute module pick its own API version produced inconsistent results across machines, and the disk cmdlets will otherwise default a Trusted Launch image lookup that is incompatible with exporting the disk to nested Hyper-V guests.

**The Azure Migrate appliance VHD Microsoft publishes for Hyper-V is Generation 1.** Module 1 creates the appliance VM with `-Generation 1` for that reason. Confirm the current generation and disk format in Microsoft's article before you run it — a Generation 2 VM will not boot a Generation 1 VHD, and the failure looks like a corrupt download.

**The lab stages the appliance on the host's own OS disk.** An earlier revision attached a separate managed data disk for this. It was removed because the 512 GB OS disk already has the capacity and a data disk bills continuously, including while the VM is deallocated.

No attempt has been made to solve for environments beyond the one this was built in. If you hit a different compatibility problem — a region without the host size, a policy that blocks disk export, a proxy that blocks a package source — please open an issue with the error and your region and subscription type. Feedback of that kind is what turns one environment's findings into guidance that holds up more broadly.

## Maintenance and provenance

Parse every script with PowerShell before sharing changes, and confirm the documentation links resolve. The host-side scripts target Windows PowerShell 5.1; the deployment client works on either 5.1 or PowerShell 7.

Preserve upstream license/attribution notices when merging this reviewed source into the workshop repository. This supplied baseline does not include a LICENSE file; do not infer Microsoft-derived attribution or silently manufacture licensing metadata.
